# Arun Pharmacy Inventory & Purchase Manager

Next.js 14 + TypeScript + Tailwind, with Supabase (Postgres, Auth, Realtime).

## Setup
1. Create a free project at supabase.com. In the SQL editor, run `supabase/schema.sql`.
2. Authentication > Users: add the owner and each staff member (email + password).
   Then in the Table editor open `profiles` and set the owner's `role` to `admin` (new users start as `staff`).
3. Copy `.env.example` to `.env.local` and fill in the project URL and anon key (Project Settings > API).
4. `npm install` then `npm run dev`. Deploy with Vercel for the phone (HTTPS is required for the camera).
5. Optional: add the `SUPABASE_DB_URL` secret on GitHub to enable the nightly backup workflow.

## How stock works
Stock is never stored. The `stock_batches` view adds purchases and subtracts sales per medicine and batch,
so editing or deleting a purchase corrects stock automatically. Billing later only needs to insert into `sales_items`.

## Offline scanning
Without a connection a saved purchase is kept on the phone and sent when the connection returns. The unique
(supplier, invoice) rule makes the resend safe. Known medicines are cached on the phone for name lookup.

## Planned next
Billing screen (writes `sales_items`), barcode label printing, customers, GST reports, WhatsApp invoice sharing,
purchase returns, PDF invoices, WhatsApp/SMS alerts. Open question: barcodes on Indian strips are often
distributor codes, so the first scan of each medicine needs its name typed once.
