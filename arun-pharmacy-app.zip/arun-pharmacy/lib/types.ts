export type Role = 'admin' | 'staff';

export type Item = {
  id: string; purchase_id: string; barcode: string | null; medicine_name: string; batch_no: string;
  mfg_date: string | null; expiry_date: string; qty: number; rate: number; mrp: number;
  discount_pct: number; gst_pct: number; line_total: number;
  purchases: { purchase_date: string; supplier: string; invoice_no: string; created_by: string };
};
export type Batch = {
  med_key: string; barcode: string | null; name: string; batch_no: string; expiry_date: string;
  qty: number; rate: number; mrp: number; min_stock: number;
};
export type Line = {
  barcode: string; name: string; manufacturer: string; batch: string; mfg: string; exp: string;
  qty: string; rate: string; mrp: string; disc: string; gst: string;
};
export type Payload = { date: string; supplier: string; invoice: string; items: Line[] };
