const pad = (n: number) => String(n).padStart(2, '0');
export const inr = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(n || 0);
export const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
export const dmy = (d?: string | null) => (d ? d.slice(0, 10).split('-').reverse().join('-') : '');
export const my = (d?: string | null) => (d ? `${d.slice(5, 7)}/${d.slice(0, 4)}` : '');
export const toMonth = (d?: string | null) => (d ? d.slice(0, 7) : '');
/** Month input (YYYY-MM) to the last day of that month, which is when a pharmacy batch expires. */
export const monthEnd = (m: string) => {
  if (!m) return '';
  const [y, mo] = m.split('-').map(Number);
  return `${y}-${pad(mo)}-${pad(new Date(y, mo, 0).getDate())}`;
};
export const daysLeft = (d: string) =>
  Math.floor((new Date(d + 'T00:00:00').getTime() - new Date(todayISO() + 'T00:00:00').getTime()) / 864e5);
export const lineTotal = (qty: number | string, rate: number | string, disc: number | string, gst: number | string) =>
  Math.round(Number(qty || 0) * Number(rate || 0) * (1 - Number(disc || 0) / 100) * (1 + Number(gst || 0) / 100) * 100) / 100;
