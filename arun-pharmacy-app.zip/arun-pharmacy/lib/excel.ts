export async function exportXlsx(
  filename: string, sheet: string, headers: string[], rows: (string | number)[][], sumCol?: number
) {
  const ExcelJS = (await import('exceljs')).default;
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet(sheet);
  ws.addRow(headers);
  const hr = ws.getRow(1);
  hr.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  hr.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0B6FB8' } };
  rows.forEach((r) => ws.addRow(r));
  headers.forEach((h, i) => { ws.getColumn(i + 1).width = Math.max(13, h.length + 3); });
  if (sumCol !== undefined && rows.length) {
    const letter = ws.getColumn(sumCol + 1).letter;
    const total = ws.addRow([]);
    total.getCell(sumCol).value = 'Grand total';
    total.getCell(sumCol + 1).value = {
      formula: `SUM(${letter}2:${letter}${rows.length + 1})`,
      result: rows.reduce((a, r) => a + Number(r[sumCol] || 0), 0),
    };
    total.font = { bold: true };
  }
  const buf = await wb.xlsx.writeBuffer();
  const url = URL.createObjectURL(new Blob([buf], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}
