'use client';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from './supabase';
import type { Batch, Item } from './types';

export const fetchItems = async (): Promise<Item[]> => {
  const { data } = await supabase
    .from('purchase_items')
    .select('*, purchases!inner(purchase_date,supplier,invoice_no,created_by)')
    .order('created_at', { ascending: false })
    .limit(5000);
  return (data as unknown as Item[]) ?? [];
};
export const fetchStock = async (): Promise<Batch[]> => {
  const { data } = await supabase.from('stock_batches').select('*').gt('qty', 0).order('name');
  return (data as Batch[]) ?? [];
};

/** Loads data and reloads it whenever another device changes one of the tables (live sync). */
export function useLive<T>(fetcher: () => Promise<T>, tables: string[], init: T) {
  const [data, setData] = useState<T>(init);
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => { setData(await fetcher()); setLoading(false); }, []); // eslint-disable-line
  useEffect(() => {
    load();
    const ch = supabase.channel('live-' + tables.join('-') + '-' + Math.random());
    tables.forEach((t) => ch.on('postgres_changes', { event: '*', schema: 'public', table: t }, () => load()));
    ch.subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [load]); // eslint-disable-line
  return { data, loading, reload: load };
}
