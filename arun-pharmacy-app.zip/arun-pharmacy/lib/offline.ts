import { supabase } from './supabase';
import type { Payload } from './types';

const K = 'arun_queue';
const read = (): Payload[] => { try { return JSON.parse(localStorage.getItem(K) || '[]'); } catch { return []; } };
export const pendingCount = () => read().length;
export const enqueue = (p: Payload) => localStorage.setItem(K, JSON.stringify([...read(), p]));

/** Sends purchases saved while offline. A duplicate (23505) means it already reached the server. */
export async function flush(): Promise<number> {
  const q = read();
  const rest: Payload[] = [];
  for (const p of q) {
    const { error } = await supabase.rpc('save_purchase', { p });
    if (error && error.code !== '23505') rest.push(p);
  }
  localStorage.setItem(K, JSON.stringify(rest));
  return q.length - rest.length;
}
