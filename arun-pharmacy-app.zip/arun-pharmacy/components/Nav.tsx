'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useMe } from './AuthGate';
import { flush, pendingCount } from '@/lib/offline';

const TABS = [
  ['/', 'Dashboard'], ['/purchase', 'Purchase Entry'], ['/entries', 'Entries'], ['/stock', 'Stock'],
  ['/expiry', 'Expiry Alert'], ['/reports', 'Reports'], ['/settings', 'Settings'],
];

export default function Nav() {
  const me = useMe();
  const path = usePathname();
  const [pending, setPending] = useState(0);
  useEffect(() => {
    const sync = async () => { if (navigator.onLine && pendingCount()) await flush(); setPending(pendingCount()); };
    sync();
    window.addEventListener('online', sync);
    const t = setInterval(sync, 20000);
    return () => { window.removeEventListener('online', sync); clearInterval(t); };
  }, []);
  const tabs = TABS.filter(([h]) => me.role === 'admin' || !['/reports', '/settings'].includes(h));
  return (
    <>
      <header className="flex flex-wrap items-center gap-3 border-b-4 border-care px-4 py-3">
        <h1 className="text-xl font-bold text-brand">Arun Pharmacy</h1>
        <span className="text-sm text-slate-500">Inventory & Purchase Manager</span>
        <span className="flex-1" />
        {pending > 0 && <span className="rounded-full border border-amber-600 px-3 text-sm text-amber-700">{pending} waiting to sync</span>}
        <span className="rounded-full border border-care px-3 text-sm text-care">{me.role === 'admin' ? 'Admin' : 'Staff'} · {me.name}</span>
        <button className="btn-sm" onClick={me.signOut}>Sign out</button>
      </header>
      <nav className="sticky top-0 z-10 flex gap-1 overflow-x-auto border-b border-line bg-white px-3 py-2">
        {tabs.map(([h, l]) => (
          <Link key={h} href={h} className={`whitespace-nowrap rounded-lg px-4 py-2 ${path === h ? 'bg-brand font-bold text-white' : 'hover:bg-soft'}`}>{l}</Link>
        ))}
      </nav>
    </>
  );
}
