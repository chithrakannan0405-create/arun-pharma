import { daysLeft } from '@/lib/util';

export default function ExpiryTag({ d }: { d: string }) {
  const n = daysLeft(d);
  return n < 0 ? <span className="tag-bad">Expired</span> : n <= 90 ? <span className="tag-bad">{n} days</span>
    : n <= 180 ? <span className="tag-warn">{n} days</span> : <span className="tag-ok">{n} days</span>;
}
