'use client';
import { createContext, useContext, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import type { Role } from '@/lib/types';

type Me = { id: string; name: string; role: Role; signOut: () => Promise<void> };
const Ctx = createContext<Me | null>(null);
export const useMe = () => useContext(Ctx)!;

export function AuthGate({ children }: { children: React.ReactNode }) {
  const [me, setMe] = useState<Omit<Me, 'signOut'> | null>(null);
  const router = useRouter();
  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { router.replace('/login'); return; }
      const { data: p } = await supabase.from('profiles').select('full_name,role').eq('id', session.user.id).single();
      setMe({ id: session.user.id, name: p?.full_name ?? session.user.email ?? '', role: (p?.role as Role) ?? 'staff' });
    })();
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { if (!s) router.replace('/login'); });
    return () => sub.subscription.unsubscribe();
  }, [router]);
  if (!me) return <p className="p-8 text-lg">Loading…</p>;
  return <Ctx.Provider value={{ ...me, signOut: async () => { await supabase.auth.signOut(); } }}>{children}</Ctx.Provider>;
}
