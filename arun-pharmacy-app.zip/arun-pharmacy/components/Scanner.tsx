'use client';
import { useEffect, useRef, useState } from 'react';

export default function Scanner({ onScan, onClose }: { onScan: (code: string) => void; onClose: () => void }) {
  const video = useRef<HTMLVideoElement>(null);
  const handler = useRef(onScan);
  handler.current = onScan;
  const [msg, setMsg] = useState('Point the camera at a barcode.');
  useEffect(() => {
    let stop = () => {};
    let last = '', t0 = 0;
    (async () => {
      try {
        const { BrowserMultiFormatReader } = await import('@zxing/browser');
        const controls = await new BrowserMultiFormatReader().decodeFromConstraints(
          { video: { facingMode: 'environment' } }, video.current!,
          (res) => {
            if (!res) return;
            const code = res.getText(), now = Date.now();
            if (code !== last || now - t0 > 2500) {
              last = code; t0 = now;
              navigator.vibrate?.(60);
              handler.current(code);
              setMsg(`Scanned ${code}. Scan the next one, or press Done.`);
            }
          });
        stop = () => controls.stop();
      } catch { setMsg('The camera is blocked. Allow camera access, or type the barcode.'); }
    })();
    return () => stop();
  }, []);
  return (
    <div className="fixed inset-0 z-20 flex flex-col gap-3 bg-black/80 p-4">
      <video ref={video} playsInline muted className="max-h-[65vh] w-full rounded-xl bg-black object-cover" />
      <p className="text-center text-lg text-white" aria-live="polite">{msg}</p>
      <button className="btn-pri mx-auto" onClick={onClose}>Done</button>
    </div>
  );
}
