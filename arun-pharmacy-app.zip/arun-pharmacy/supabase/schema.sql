-- Arun Pharmacy Inventory & Purchase Manager: run once in the Supabase SQL editor.
create type app_role as enum ('admin', 'staff');

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text,
  role app_role not null default 'staff'
);
create function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into profiles (id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email)); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

create function is_member() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from profiles where id = auth.uid()) $$;
create function is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;

create table medicines (
  barcode text primary key,
  name text not null,
  generic_name text,
  manufacturer text,
  category text,
  min_stock int not null default 20,
  updated_at timestamptz not null default now()
);

create table purchases (
  id uuid primary key default gen_random_uuid(),
  purchase_date date not null default current_date,
  supplier text not null,
  invoice_no text not null,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now(),
  unique (supplier, invoice_no)
);

create table purchase_items (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references purchases on delete cascade,
  barcode text references medicines on update cascade,
  medicine_name text not null,
  batch_no text not null,
  mfg_date date,
  expiry_date date not null,
  qty int not null check (qty > 0),
  rate numeric(12,2) not null,
  mrp numeric(12,2) not null default 0,
  discount_pct numeric(5,2) not null default 0,
  gst_pct numeric(5,2) not null default 0,
  line_total numeric(12,2) generated always as
    (round(qty * rate * (1 - discount_pct / 100) * (1 + gst_pct / 100), 2)) stored,
  created_at timestamptz not null default now()
);
create index on purchase_items (barcode);
create index on purchase_items (expiry_date);

-- Future billing writes here; stock already subtracts it.
create table sales_items (
  id uuid primary key default gen_random_uuid(),
  barcode text,
  medicine_name text not null,
  batch_no text not null,
  qty int not null check (qty > 0),
  sold_at timestamptz not null default now(),
  created_by uuid default auth.uid()
);

-- Stock is always derived (purchases minus sales), so edits and deletes recalculate it by design.
create view stock_batches with (security_invoker = true) as
select p.med_key, p.barcode, p.name, p.batch_no, p.expiry_date,
       (p.bought - coalesce(s.sold, 0))::int as qty, p.rate, p.mrp, coalesce(m.min_stock, 20) as min_stock
from (
  select coalesce(barcode, lower(medicine_name)) as med_key, max(barcode) as barcode,
         (array_agg(medicine_name order by created_at desc))[1] as name,
         upper(trim(batch_no)) as batch_key,
         (array_agg(batch_no order by created_at desc))[1] as batch_no,
         (array_agg(expiry_date order by created_at desc))[1] as expiry_date,
         sum(qty) as bought,
         (array_agg(rate order by created_at desc))[1] as rate,
         (array_agg(mrp order by created_at desc))[1] as mrp
  from purchase_items group by 1, 4
) p
left join (
  select coalesce(barcode, lower(medicine_name)) as med_key, upper(trim(batch_no)) as batch_key, sum(qty) as sold
  from sales_items group by 1, 2
) s using (med_key, batch_key)
left join medicines m on m.barcode = p.barcode;

-- One transaction per purchase; used by the app and by the offline sync.
create function save_purchase(p jsonb) returns uuid language plpgsql as $$
declare pid uuid; it jsonb;
begin
  insert into purchases (purchase_date, supplier, invoice_no)
  values ((p->>'date')::date, p->>'supplier', p->>'invoice') returning id into pid;
  for it in select * from jsonb_array_elements(p->'items') loop
    if nullif(it->>'barcode', '') is not null then
      insert into medicines (barcode, name, manufacturer)
      values (it->>'barcode', it->>'name', nullif(it->>'manufacturer', ''))
      on conflict (barcode) do update set name = excluded.name,
        manufacturer = coalesce(excluded.manufacturer, medicines.manufacturer), updated_at = now();
    end if;
    insert into purchase_items (purchase_id, barcode, medicine_name, batch_no, mfg_date, expiry_date, qty, rate, mrp, discount_pct, gst_pct)
    values (pid, nullif(it->>'barcode', ''), it->>'name', it->>'batch', nullif(it->>'mfg', '')::date, (it->>'exp')::date,
            (it->>'qty')::int, (it->>'rate')::numeric, coalesce(nullif(it->>'mrp', '')::numeric, 0),
            coalesce(nullif(it->>'disc', '')::numeric, 0), coalesce(nullif(it->>'gst', '')::numeric, 0));
  end loop;
  return pid;
end $$;

-- Row level security. Admin: everything. Staff: read, add, and edit their own entries made today.
alter table profiles enable row level security;
alter table medicines enable row level security;
alter table purchases enable row level security;
alter table purchase_items enable row level security;
alter table sales_items enable row level security;

create policy "read own or admin profiles" on profiles for select using (id = auth.uid() or is_admin());
create policy "admin edits profiles" on profiles for update using (is_admin());

create policy "members read medicines" on medicines for select using (is_member());
create policy "members add medicines" on medicines for insert with check (is_member());
create policy "members update medicines" on medicines for update using (is_member());
create policy "admin deletes medicines" on medicines for delete using (is_admin());

create policy "members read purchases" on purchases for select using (is_member());
create policy "members add purchases" on purchases for insert with check (is_member());
create policy "edit purchases" on purchases for update
  using (is_admin() or (created_by = auth.uid() and purchase_date = current_date));
create policy "admin deletes purchases" on purchases for delete using (is_admin());

create policy "members read items" on purchase_items for select using (is_member());
create policy "members add items" on purchase_items for insert with check (is_member());
create policy "edit items" on purchase_items for update using (
  is_admin() or exists (select 1 from purchases x where x.id = purchase_id and x.created_by = auth.uid() and x.purchase_date = current_date));
create policy "admin deletes items" on purchase_items for delete using (is_admin());

create policy "members read sales" on sales_items for select using (is_member());
create policy "members add sales" on sales_items for insert with check (is_member());
create policy "admin edits sales" on sales_items for all using (is_admin());

-- Live sync between phone and computer.
alter publication supabase_realtime add table purchases, purchase_items, sales_items;
