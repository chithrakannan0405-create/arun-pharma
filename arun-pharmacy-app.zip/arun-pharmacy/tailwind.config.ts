import type { Config } from 'tailwindcss';
export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: { colors: { brand: { DEFAULT: '#0b6fb8', dark: '#085a96' }, care: '#16875c', soft: '#f0f8fb', line: '#d5e4ea' } } },
  plugins: [],
} satisfies Config;
