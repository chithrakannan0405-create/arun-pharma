import './globals.css';
import { Atkinson_Hyperlegible } from 'next/font/google';

const font = Atkinson_Hyperlegible({ subsets: ['latin'], weight: ['400', '700'] });
export const metadata = { title: 'Arun Pharmacy Inventory & Purchase Manager' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en"><body className={font.className}>{children}</body></html>
  );
}
