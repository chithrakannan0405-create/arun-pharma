'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const router = useRouter();
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setMsg('Email or password is not correct.'); else router.replace('/');
  }
  return (
    <form onSubmit={submit} className="mx-auto mt-[12vh] grid max-w-sm gap-4 p-5">
      <h1 className="text-2xl font-bold text-brand">Arun Pharmacy</h1>
      <p className="text-slate-500">Inventory & Purchase Manager</p>
      <label>Email<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
      <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>
      <button className="btn-pri">Sign in</button>
      {msg && <p className="text-red-700">{msg}</p>}
    </form>
  );
}
