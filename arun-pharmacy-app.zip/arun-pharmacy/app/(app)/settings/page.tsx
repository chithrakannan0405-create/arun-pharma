'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useMe } from '@/components/AuthGate';
import type { Role } from '@/lib/types';

type Med = { barcode: string; name: string; min_stock: number };
type Prof = { id: string; full_name: string | null; role: Role };

export default function Settings() {
  const me = useMe();
  const [meds, setMeds] = useState<Med[]>([]);
  const [users, setUsers] = useState<Prof[]>([]);
  const [msg, setMsg] = useState('');
  useEffect(() => {
    supabase.from('medicines').select('barcode,name,min_stock').order('name').then(({ data }) => setMeds((data as Med[]) ?? []));
    supabase.from('profiles').select('id,full_name,role').then(({ data }) => setUsers((data as Prof[]) ?? []));
  }, []);
  if (me.role !== 'admin') return <p>Settings are for the admin.</p>;
  async function setMin(m: Med, v: number) {
    setMeds((x) => x.map((k) => (k.barcode === m.barcode ? { ...k, min_stock: v } : k)));
    const { error } = await supabase.from('medicines').update({ min_stock: v }).eq('barcode', m.barcode);
    setMsg(error ? 'Could not save.' : 'Saved.');
  }
  async function setRole(u: Prof, role: Role) {
    setUsers((x) => x.map((k) => (k.id === u.id ? { ...k, role } : k)));
    const { error } = await supabase.from('profiles').update({ role }).eq('id', u.id);
    setMsg(error ? 'Could not save.' : 'Saved.');
  }
  return (
    <>
      <h2 className="mb-3 text-2xl font-bold">Settings</h2>
      <h3 className="mb-2 text-lg font-bold">Staff and admins</h3>
      <p className="mb-2 text-sm text-slate-500">Add people in Supabase under Authentication, then set their role here.</p>
      <div className="mb-6 grid gap-2">{users.map((u) => (
        <label key={u.id} className="flex-row items-center gap-3"><span className="flex-1 text-base text-slate-800">{u.full_name}</span>
          <select className="!w-40" value={u.role} onChange={(e) => setRole(u, e.target.value as Role)} disabled={u.id === me.id}>
            <option value="admin">Admin</option><option value="staff">Staff</option></select></label>))}</div>
      <h3 className="mb-2 text-lg font-bold">Low stock level per medicine</h3>
      <div className="grid gap-2">{meds.map((m) => (
        <label key={m.barcode} className="flex-row items-center gap-3"><span className="flex-1 text-base text-slate-800">{m.name}</span>
          <input className="!w-28" type="number" min={0} defaultValue={m.min_stock} onBlur={(e) => setMin(m, Number(e.target.value))} /></label>))}
        {!meds.length && <p className="text-slate-500">Medicines appear here after their first scanned purchase.</p>}</div>
      {msg && <p className="mt-3 text-care">{msg}</p>}
    </>
  );
}
