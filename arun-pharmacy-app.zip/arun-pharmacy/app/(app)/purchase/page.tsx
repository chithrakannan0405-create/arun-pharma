'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import Scanner from '@/components/Scanner';
import { enqueue } from '@/lib/offline';
import { inr, lineTotal, monthEnd, todayISO } from '@/lib/util';
import type { Line, Payload } from '@/lib/types';

const MK = 'arun_meds';
type Med = { name: string; manufacturer: string | null };
const cache = (): Record<string, Med> => { try { return JSON.parse(localStorage.getItem(MK) || '{}'); } catch { return {}; } };
const blank = (barcode = '', m?: Med): Line => ({
  barcode, name: m?.name ?? '', manufacturer: m?.manufacturer ?? '', batch: '', mfg: '', exp: '',
  qty: '1', rate: '', mrp: '', disc: '0', gst: '12',
});

export default function Purchase() {
  const [date, setDate] = useState(todayISO());
  const [supplier, setSupplier] = useState('');
  const [invoice, setInvoice] = useState('');
  const [lines, setLines] = useState<Line[]>([]);
  const [scan, setScan] = useState(false);
  const [bc, setBc] = useState('');
  const [msg, setMsg] = useState('');
  const [suppliers, setSuppliers] = useState<string[]>([]);

  useEffect(() => {
    (async () => {
      if (!navigator.onLine) return;
      const { data } = await supabase.from('medicines').select('barcode,name,manufacturer');
      if (data) localStorage.setItem(MK, JSON.stringify(Object.fromEntries(data.map((m) => [m.barcode, m]))));
      const { data: p } = await supabase.from('purchases').select('supplier').limit(500);
      if (p) setSuppliers([...new Set(p.map((x) => x.supplier))]);
    })();
  }, []);

  const add = (code: string) => setLines((l) => [...l, blank(code, cache()[code])]);
  const set = (i: number, f: keyof Line, v: string) => setLines((l) => l.map((x, k) => (k === i ? { ...x, [f]: v } : x)));
  const grand = lines.reduce((a, l) => a + lineTotal(l.qty, l.rate, l.disc, l.gst), 0);

  async function save() {
    if (!supplier.trim() || !invoice.trim()) return setMsg('Enter the supplier name and invoice number.');
    for (const [i, l] of lines.entries())
      if (!l.name.trim() || !l.batch.trim() || !l.exp || !(Number(l.qty) > 0) || l.rate === '')
        return setMsg(`Item ${i + 1}: fill medicine, batch, expiry, quantity and rate.`);
    const payload: Payload = {
      date, supplier: supplier.trim(), invoice: invoice.trim(),
      items: lines.map((l) => ({ ...l, mfg: l.mfg ? l.mfg + '-01' : '', exp: monthEnd(l.exp) })),
    };
    const res = navigator.onLine ? await supabase.rpc('save_purchase', { p: payload }) : { error: { code: 'offline', message: 'offline' } };
    if (res.error) {
      if (res.error.code === '23505') return setMsg('This invoice number is already saved for this supplier.');
      if (/^[0-9A-Z]{5}$/.test(res.error.code || '')) return setMsg('Could not save: ' + res.error.message);
      enqueue(payload);
      setMsg('No connection. Saved on this phone and it will sync automatically.');
    } else setMsg('Purchase saved. Stock updated.');
    setLines([]); setInvoice('');
  }

  const F = (i: number, label: string, f: keyof Line, type = 'text', extra: object = {}) => (
    <label>{label}<input type={type} value={lines[i][f]} onChange={(e) => set(i, f, e.target.value)} {...extra} /></label>
  );
  return (
    <>
      <h2 className="mb-3 text-2xl font-bold">Purchase Entry</h2>
      <div className="grid-f">
        <label>Date<input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
        <label>Supplier<input list="sup" value={supplier} onChange={(e) => setSupplier(e.target.value)} /></label>
        <label>Invoice no<input value={invoice} onChange={(e) => setInvoice(e.target.value)} /></label>
      </div>
      <datalist id="sup">{suppliers.map((s) => <option key={s} value={s} />)}</datalist>
      <div className="my-4 flex flex-wrap items-end gap-3">
        <button className="btn-grn" onClick={() => setScan(true)}>Scan medicine</button>
        <label className="min-w-[200px] flex-1">Or type a barcode
          <input value={bc} inputMode="numeric" onChange={(e) => setBc(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && bc.trim()) { add(bc.trim()); setBc(''); } }} /></label>
        <button className="btn" onClick={() => { if (bc.trim()) { add(bc.trim()); setBc(''); } }}>Add</button>
        <button className="btn" onClick={() => add('')}>Add without barcode</button>
      </div>
      {!lines.length && <p className="rounded-lg border-2 border-dashed border-line p-6 text-center text-slate-500">Scan the first medicine to start this purchase list.</p>}
      {lines.map((l, i) => (
        <div key={i} className="my-3 rounded-xl border-2 border-line p-3">
          <div className="mb-2 flex flex-wrap items-center gap-3">
            <h3 className="text-lg font-bold">{l.name || 'New medicine'}</h3>
            <span className="text-sm text-slate-500">{l.barcode}{l.manufacturer && ` · ${l.manufacturer}`}</span>
            <span className="flex-1" />
            <b>{inr(lineTotal(l.qty, l.rate, l.disc, l.gst))}</b>
            <button className="btn-bad" onClick={() => setLines((x) => x.filter((_, k) => k !== i))}>Remove</button>
          </div>
          <div className="grid-f">
            {F(i, 'Medicine name', 'name')}{F(i, 'Batch no', 'batch')}{F(i, 'Mfg (month)', 'mfg', 'month')}{F(i, 'Expiry (month)', 'exp', 'month')}
            {F(i, 'Quantity', 'qty', 'number', { min: 1, inputMode: 'numeric' })}{F(i, 'Purchase rate', 'rate', 'number', { step: 'any', inputMode: 'decimal' })}
            {F(i, 'MRP', 'mrp', 'number', { step: 'any' })}{F(i, 'Discount %', 'disc', 'number', { step: 'any' })}{F(i, 'GST %', 'gst', 'number', { step: 'any' })}
          </div>
        </div>
      ))}
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <h3 className="flex-1 text-lg font-bold">{lines.length} items · Grand total {inr(grand)}</h3>
        <button className="btn-pri" disabled={!lines.length} onClick={save}>Save purchase</button>
      </div>
      {msg && <p className="mt-3 text-lg" role="status">{msg}</p>}
      {scan && <Scanner onScan={add} onClose={() => setScan(false)} />}
    </>
  );
}
