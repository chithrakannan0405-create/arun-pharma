'use client';
import { useState } from 'react';
import { fetchItems, fetchStock } from '@/lib/hooks';
import { exportXlsx } from '@/lib/excel';
import { useMe } from '@/components/AuthGate';
import { daysLeft, dmy, my, todayISO } from '@/lib/util';
import type { Item } from '@/lib/types';

const H = ['Date', 'Invoice No', 'Supplier', 'Medicine Name', 'Batch No', 'Expiry Date', 'Quantity', 'Purchase Rate', 'MRP', 'GST', 'Total Amount'];
const row = (i: Item) => [dmy(i.purchases.purchase_date), i.purchases.invoice_no, i.purchases.supplier, i.medicine_name, i.batch_no,
  my(i.expiry_date), i.qty, i.rate, i.mrp, `${i.gst_pct}%`, i.line_total];

export default function Reports() {
  const me = useMe();
  const [day, setDay] = useState(todayISO());
  const [month, setMonth] = useState(todayISO().slice(0, 7));
  const [supplier, setSupplier] = useState('');
  const [suppliers, setSuppliers] = useState<string[]>([]);
  const [msg, setMsg] = useState('');
  if (me.role !== 'admin') return <p>Reports are for the admin.</p>;

  async function go(kind: 'day' | 'month' | 'supplier' | 'stock' | 'expiry') {
    setMsg('');
    const items = await fetchItems();
    setSuppliers([...new Set(items.map((i) => i.purchases.supplier))].sort());
    const t = dmy(todayISO());
    const none = () => setMsg('No data for this report.');
    if (kind === 'day') {
      const r = items.filter((i) => i.purchases.purchase_date === day).map(row);
      return r.length ? exportXlsx(`Arun_Pharmacy_Purchase_${dmy(day)}.xlsx`, 'Daily', H, r, 10) : none();
    }
    if (kind === 'month') {
      const r = items.filter((i) => i.purchases.purchase_date.startsWith(month)).map(row);
      return r.length ? exportXlsx(`Arun_Pharmacy_Purchase_${month.slice(5)}-${month.slice(0, 4)}.xlsx`, 'Monthly', H, r, 10) : none();
    }
    if (kind === 'supplier') {
      const s = supplier || items[0]?.purchases.supplier;
      const r = items.filter((i) => i.purchases.supplier === s).map(row);
      return r.length ? exportXlsx(`Arun_Pharmacy_Supplier_${s.replace(/\W+/g, '_')}_${t}.xlsx`, 'Supplier', H, r, 10) : none();
    }
    const stock = await fetchStock();
    if (kind === 'stock')
      return stock.length ? exportXlsx(`Arun_Pharmacy_Stock_${t}.xlsx`, 'Stock',
        ['Medicine', 'Barcode', 'Batch No', 'Expiry Date', 'Quantity', 'Purchase Rate', 'MRP', 'Stock Value'],
        stock.map((b) => [b.name, b.barcode ?? '', b.batch_no, my(b.expiry_date), b.qty, b.rate, b.mrp, Math.round(b.qty * b.rate * 100) / 100]), 7) : none();
    const e = stock.filter((b) => daysLeft(b.expiry_date) <= 365).sort((a, b) => daysLeft(a.expiry_date) - daysLeft(b.expiry_date));
    return e.length ? exportXlsx(`Arun_Pharmacy_Expiry_${t}.xlsx`, 'Expiry', ['Medicine', 'Batch No', 'Expiry Date', 'Days Left', 'Quantity', 'Stock Value'],
      e.map((b) => [b.name, b.batch_no, my(b.expiry_date), daysLeft(b.expiry_date), b.qty, Math.round(b.qty * b.rate * 100) / 100]), 5) : none();
  }
  return (
    <>
      <h2 className="mb-3 text-2xl font-bold">Reports (Excel)</h2>
      <div className="grid-f">
        <label>Daily report date<input type="date" value={day} onChange={(e) => setDay(e.target.value)} /></label>
        <label>Month<input type="month" value={month} onChange={(e) => setMonth(e.target.value)} /></label>
        <label>Supplier<input list="sups" value={supplier} onFocus={async () => setSuppliers([...new Set((await fetchItems()).map((i) => i.purchases.supplier))].sort())}
          onChange={(e) => setSupplier(e.target.value)} placeholder="Choose a supplier" /></label>
      </div>
      <datalist id="sups">{suppliers.map((s) => <option key={s} value={s} />)}</datalist>
      <div className="my-4 flex flex-wrap gap-3">
        <button className="btn-pri" onClick={() => go('day')}>Daily purchases</button>
        <button className="btn-pri" onClick={() => go('month')}>Monthly purchases</button>
        <button className="btn-pri" onClick={() => go('supplier')}>Supplier-wise</button>
        <button className="btn-grn" onClick={() => go('stock')}>Stock report</button>
        <button className="btn-grn" onClick={() => go('expiry')}>Expiry report</button>
      </div>
      {msg && <p className="text-red-700">{msg}</p>}
      <p className="text-sm text-slate-500">Each file ends with a Grand total row that uses an Excel SUM formula.</p>
    </>
  );
}
