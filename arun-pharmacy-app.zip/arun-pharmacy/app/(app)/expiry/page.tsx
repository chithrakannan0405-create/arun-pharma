'use client';
import { useState } from 'react';
import { fetchStock, useLive } from '@/lib/hooks';
import { daysLeft, inr, my } from '@/lib/util';
import ExpiryTag from '@/components/ExpiryTag';

const RANGES: [number, string][] = [[-1, 'Expired'], [90, '3 months'], [180, '6 months'], [365, '1 year']];

export default function Expiry() {
  const { data: stock } = useLive(fetchStock, ['purchase_items', 'sales_items'], []);
  const [r, setR] = useState(90);
  const rows = stock.filter((b) => (r < 0 ? daysLeft(b.expiry_date) < 0 : daysLeft(b.expiry_date) <= r))
    .sort((a, b) => daysLeft(a.expiry_date) - daysLeft(b.expiry_date));
  return (
    <>
      <h2 className="mb-3 text-2xl font-bold">Expiry Alert</h2>
      <div className="mb-3 flex flex-wrap gap-2">
        {RANGES.map(([v, l]) => <button key={v} className={r === v ? 'btn-pri' : 'btn'} onClick={() => setR(v)}>{l}</button>)}
      </div>
      <div className="overflow-x-auto rounded-lg border border-line">
        <table className="w-full"><thead><tr><th>Medicine</th><th>Batch</th><th>Expiry</th><th>Time left</th><th>Units</th><th>Value</th></tr></thead>
          <tbody>{rows.map((b) => (
            <tr key={b.med_key + b.batch_no}><td>{b.name}</td><td>{b.batch_no}</td><td>{my(b.expiry_date)}</td>
              <td><ExpiryTag d={b.expiry_date} /></td><td>{b.qty}</td><td>{inr(b.qty * b.rate)}</td></tr>
          ))}</tbody></table>
        {!rows.length && <p className="p-6 text-center text-slate-500">Nothing in this range.</p>}
      </div>
    </>
  );
}
