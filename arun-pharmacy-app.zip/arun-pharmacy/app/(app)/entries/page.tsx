'use client';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { fetchItems, useLive } from '@/lib/hooks';
import { useMe } from '@/components/AuthGate';
import { dmy, inr, monthEnd, my, todayISO, toMonth } from '@/lib/util';
import type { Item } from '@/lib/types';

export default function Entries() {
  const me = useMe();
  const { data: items, reload } = useLive(fetchItems, ['purchase_items', 'purchases'], []);
  const [q, setQ] = useState('');
  const [edit, setEdit] = useState<Item | null>(null);
  const [del, setDel] = useState<Item | null>(null);
  const [f, setF] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState('');
  const t = todayISO();
  const shown = items.filter((i) =>
    !q || [i.medicine_name, i.batch_no, i.barcode, i.purchases.supplier, i.purchases.invoice_no, dmy(i.purchases.purchase_date), my(i.expiry_date)]
      .join(' ').toLowerCase().includes(q.toLowerCase()));
  const canEdit = (i: Item) => me.role === 'admin' || (i.purchases.created_by === me.id && i.purchases.purchase_date === t);

  function open(i: Item) {
    setEdit(i); setMsg('');
    setF({ date: i.purchases.purchase_date, invoice: i.purchases.invoice_no, supplier: i.purchases.supplier, name: i.medicine_name,
      batch: i.batch_no, mfg: toMonth(i.mfg_date), exp: toMonth(i.expiry_date), qty: String(i.qty), rate: String(i.rate),
      mrp: String(i.mrp), disc: String(i.discount_pct), gst: String(i.gst_pct) });
  }
  async function saveEdit() {
    if (!edit) return;
    if (!f.name.trim() || !f.batch.trim() || !f.exp || !(Number(f.qty) > 0)) return setMsg('Medicine, batch, expiry and quantity are required.');
    const a = await supabase.from('purchases').update({ purchase_date: f.date, invoice_no: f.invoice.trim(), supplier: f.supplier.trim() })
      .eq('id', edit.purchase_id).select();
    const b = await supabase.from('purchase_items').update({
      medicine_name: f.name.trim(), batch_no: f.batch.trim(), mfg_date: f.mfg ? f.mfg + '-01' : null, expiry_date: monthEnd(f.exp),
      qty: Number(f.qty), rate: Number(f.rate), mrp: Number(f.mrp) || 0, discount_pct: Number(f.disc) || 0, gst_pct: Number(f.gst) || 0,
    }).eq('id', edit.id).select();
    if (a.error || b.error || !a.data?.length || !b.data?.length) return setMsg('Could not save. Staff can only edit their own entries made today.');
    setEdit(null); reload();
  }
  async function remove() {
    if (!del) return;
    const { data } = await supabase.from('purchase_items').delete().eq('id', del.id).select();
    if (!data?.length) { setMsg('Only an admin can delete entries.'); return; }
    const { count } = await supabase.from('purchase_items').select('id', { count: 'exact', head: true }).eq('purchase_id', del.purchase_id);
    if (!count) await supabase.from('purchases').delete().eq('id', del.purchase_id);
    setDel(null); reload();
  }
  const Fi = (label: string, k: string, type = 'text', extra: object = {}) => (
    <label>{label}<input type={type} value={f[k] ?? ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} {...extra} /></label>
  );
  return (
    <>
      <h2 className="mb-3 text-2xl font-bold">Purchase Entries</h2>
      <label>Search medicine, batch, supplier, invoice, date or expiry<input value={q} onChange={(e) => setQ(e.target.value)} /></label>
      <div className="mt-3 overflow-x-auto rounded-lg border border-line">
        <table className="w-full"><thead><tr><th>Date</th><th>Invoice</th><th>Supplier</th><th>Medicine</th><th>Batch</th><th>Expiry</th><th>Qty</th><th>Rate</th><th>Total</th><th /></tr></thead>
          <tbody>{shown.map((i) => (
            <tr key={i.id}><td>{dmy(i.purchases.purchase_date)}</td><td>{i.purchases.invoice_no}</td><td>{i.purchases.supplier}</td><td>{i.medicine_name}</td>
              <td>{i.batch_no}</td><td>{my(i.expiry_date)}</td><td>{i.qty}</td><td>{inr(i.rate)}</td><td>{inr(i.line_total)}</td>
              <td className="space-x-2">{canEdit(i) && <button className="btn-sm" onClick={() => open(i)}>Edit</button>}
                {me.role === 'admin' && <button className="btn-bad" onClick={() => { setDel(i); setMsg(''); }}>Delete</button>}</td></tr>
          ))}</tbody></table>
        {!shown.length && <p className="p-6 text-center text-slate-500">No entries match.</p>}
      </div>
      {me.role === 'staff' && <p className="mt-2 text-sm text-slate-500">Staff can edit their own entries made today. Deleting needs the admin.</p>}
      {edit && (
        <div className="fixed inset-0 z-20 grid place-items-center overflow-y-auto bg-black/60 p-3">
          <div className="w-full max-w-xl rounded-xl bg-white p-4">
            <h3 className="mb-3 text-lg font-bold">Edit entry</h3>
            <div className="grid-f">{Fi('Date', 'date', 'date')}{Fi('Invoice no', 'invoice')}{Fi('Supplier', 'supplier')}{Fi('Medicine', 'name')}{Fi('Batch no', 'batch')}
              {Fi('Mfg', 'mfg', 'month')}{Fi('Expiry', 'exp', 'month')}{Fi('Quantity', 'qty', 'number', { min: 1 })}{Fi('Rate', 'rate', 'number', { step: 'any' })}
              {Fi('MRP', 'mrp', 'number', { step: 'any' })}{Fi('Discount %', 'disc', 'number', { step: 'any' })}{Fi('GST %', 'gst', 'number', { step: 'any' })}</div>
            {msg && <p className="mt-2 text-red-700">{msg}</p>}
            <p className="mt-2 text-sm text-slate-500">Stock recalculates automatically from the saved entries.</p>
            <div className="mt-3 flex gap-3"><button className="btn" onClick={() => setEdit(null)}>Cancel</button><button className="btn-pri" onClick={saveEdit}>Save changes</button></div>
          </div>
        </div>)}
      {del && (
        <div className="fixed inset-0 z-20 grid place-items-center bg-black/60 p-3">
          <div className="w-full max-w-md rounded-xl bg-white p-4">
            <h3 className="mb-2 text-lg font-bold">Delete this entry?</h3>
            <p>{del.medicine_name}, batch {del.batch_no}, invoice {del.purchases.invoice_no}.<br />Stock for this batch will reduce by <b>{del.qty}</b>.</p>
            {msg && <p className="mt-2 text-red-700">{msg}</p>}
            <div className="mt-3 flex gap-3"><button className="btn" onClick={() => setDel(null)}>Keep it</button><button className="btn-bad" onClick={remove}>Delete entry</button></div>
          </div>
        </div>)}
    </>
  );
}
