'use client';
import { useState } from 'react';
import { fetchStock, useLive } from '@/lib/hooks';
import ExpiryTag from '@/components/ExpiryTag';
import { inr, my } from '@/lib/util';

export default function Stock() {
  const { data: stock } = useLive(fetchStock, ['purchase_items', 'sales_items'], []);
  const [q, setQ] = useState('');
  const totals = new Map<string, number>();
  stock.forEach((b) => totals.set(b.med_key, (totals.get(b.med_key) ?? 0) + b.qty));
  const shown = stock.filter((b) => !q || [b.name, b.batch_no, b.barcode, my(b.expiry_date)].join(' ').toLowerCase().includes(q.toLowerCase()));
  return (
    <>
      <h2 className="mb-3 text-2xl font-bold">Stock (batch-wise)</h2>
      <label>Search medicine, batch, barcode or expiry<input value={q} onChange={(e) => setQ(e.target.value)} /></label>
      <div className="mt-3 overflow-x-auto rounded-lg border border-line">
        <table className="w-full"><thead><tr><th>Medicine</th><th>Barcode</th><th>Batch</th><th>Expiry</th><th>Left</th><th>Rate</th><th>MRP</th><th>Value</th></tr></thead>
          <tbody>{shown.map((b) => (
            <tr key={b.med_key + b.batch_no}>
              <td>{b.name} {(totals.get(b.med_key) ?? 0) < b.min_stock && <span className="tag-warn">Low</span>}</td>
              <td>{b.barcode}</td><td>{b.batch_no}</td><td>{my(b.expiry_date)} <ExpiryTag d={b.expiry_date} /></td>
              <td>{b.qty}</td><td>{inr(b.rate)}</td><td>{inr(b.mrp)}</td><td>{inr(b.qty * b.rate)}</td></tr>
          ))}</tbody></table>
        {!shown.length && <p className="p-6 text-center text-slate-500">No stock to show yet.</p>}
      </div>
    </>
  );
}
