'use client';
import { useMemo } from 'react';
import { fetchItems, fetchStock, useLive } from '@/lib/hooks';
import { daysLeft, dmy, inr, todayISO } from '@/lib/util';

export default function Dashboard() {
  const { data: items } = useLive(fetchItems, ['purchase_items'], []);
  const { data: stock } = useLive(fetchStock, ['purchase_items', 'sales_items'], []);
  const s = useMemo(() => {
    const meds = new Map<string, { name: string; qty: number; min: number }>();
    stock.forEach((b) => {
      const m = meds.get(b.med_key) ?? { name: b.name, qty: 0, min: b.min_stock };
      m.qty += b.qty; meds.set(b.med_key, m);
    });
    const low = [...meds.values()].filter((m) => m.qty < m.min);
    const t = todayISO();
    return {
      meds: meds.size, units: stock.reduce((a, b) => a + b.qty, 0),
      value: stock.reduce((a, b) => a + b.qty * b.rate, 0), low,
      expiring: stock.filter((b) => daysLeft(b.expiry_date) <= 90).length,
      today: items.filter((i) => i.purchases.purchase_date === t).reduce((a, i) => a + i.line_total, 0),
    };
  }, [items, stock]);
  const recent = [...items].sort((a, b) => b.purchases.purchase_date.localeCompare(a.purchases.purchase_date)).slice(0, 6);
  return (
    <>
      <h2 className="mb-3 text-2xl font-bold">Dashboard</h2>
      <div className="mb-6 grid grid-cols-[repeat(auto-fit,minmax(160px,1fr))] gap-3">
        <div className="stat"><b>{s.meds}</b>Medicines available</div>
        <div className="stat"><b>{s.units}</b>Units in stock</div>
        <div className="stat"><b>{inr(s.value)}</b>Stock value</div>
        <div className="stat !border-amber-600"><b>{s.low.length}</b>Low stock medicines</div>
        <div className="stat !border-amber-600"><b>{s.expiring}</b>Batches expiring in 3 months</div>
        <div className="stat"><b>{inr(s.today)}</b>Purchased today</div>
      </div>
      <h3 className="mb-2 text-lg font-bold">Recent purchases</h3>
      <div className="mb-6 overflow-x-auto rounded-lg border border-line">
        <table className="w-full"><thead><tr><th>Date</th><th>Invoice</th><th>Medicine</th><th>Batch</th><th>Qty</th><th>Total</th></tr></thead>
          <tbody>{recent.map((i) => (
            <tr key={i.id}><td>{dmy(i.purchases.purchase_date)}</td><td>{i.purchases.invoice_no}</td><td>{i.medicine_name}</td><td>{i.batch_no}</td><td>{i.qty}</td><td>{inr(i.line_total)}</td></tr>
          ))}</tbody></table>
        {!recent.length && <p className="p-6 text-center text-slate-500">No purchases yet. Open Purchase Entry to add the first one.</p>}
      </div>
      <h3 className="mb-2 text-lg font-bold">Low stock</h3>
      {s.low.length ? <ul className="grid gap-1">{s.low.map((m) => <li key={m.name}>{m.name}: <span className="tag-bad">{m.qty} left</span></li>)}</ul> : <p className="text-slate-500">Nothing is running low.</p>}
    </>
  );
}
